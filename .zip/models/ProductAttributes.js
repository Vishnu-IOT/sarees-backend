const { DataTypes } = require("sequelize");
const sequelize = require("../config/mysqldb");

const Product = require("./Products");

const ProductAttribute = sequelize.define(
    "ProductAttribute",
    {
        id: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
        },

        productId: {
            type: DataTypes.INTEGER,
            allowNull: false,
        },

        image_url: {
            type: DataTypes.STRING,
            allowNull: true,
        },

        discount: {
            type: DataTypes.INTEGER,
            allowNull: true,
            defaultValue: 0,
        },

        price: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: false,
        },

        offerPrice: {
            type: DataTypes.DECIMAL(10, 2),
            allowNull: true
        },

        color: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        sku: {
            type: DataTypes.STRING,
            unique: true,
        },

        fabric: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        work: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        blouseLength: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        occasion: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        metal: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        purity: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        stone: {
            type: DataTypes.JSON,
            allowNull: true,
        },

        weight: {
            type: DataTypes.STRING,
            allowNull: true,
        },

        size: {
            type: DataTypes.JSON,
            allowNull: true,
        },
    },
    {
        tableName: "product_attributes",
        timestamps: true,
    }
);

Product.hasMany(ProductAttribute, {
    foreignKey: {
        name: "productId",
        allowNull: false,
    },
    onDelete: "CASCADE",
    as: "attributes",
});

ProductAttribute.belongsTo(Product, {
    foreignKey: {
        name: "productId",
        allowNull: false,
    },
    onDelete: "CASCADE",
    as: "product",
});

module.exports = ProductAttribute;