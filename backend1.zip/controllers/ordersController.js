const sequelize = require("../config/mysqldb");
const { Op, fn, col } = require("sequelize");
const Order = require("../models/Orders");
const OrderItem = require("../models/OrderItems");
const Product = require("../models/Products");
const ProductAttribute = require("../models/ProductAttributes");
const User = require("../models/User");
const Customer = require("../models/Customer");
const { sendOrderStatusEmail } = require("../middlewares/emailServices");

// ✅ ADMIN FUNCTION: Get all orders (existing)
async function GetOrders(req, res) {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        const search = req.query.search || "";
        const status = req.query.status || "";
        const paymentStatus = req.query.paymentStatus || "";
        const sort = req.query.sort === "ASC" ? "ASC" : "DESC";

        const where = {};

        if (status) {
            where.status = status;
        }

        if (paymentStatus) {
            where.paymentStatus = paymentStatus;
        }

        if (search) {
            where[Op.or] = [
                {
                    orderNumber: {
                        [Op.like]: `%${search}%`,
                    },
                },
                {
                    "$customer.name$": {
                        [Op.like]: `%${search}%`,
                    },
                },
                {
                    "$customer.phone$": {
                        [Op.like]: `%${search}%`,
                    },
                },
            ];
        }

        const { count, rows } = await Order.findAndCountAll({
            where,
            attributes: [
                "id",
                "userId",
                "orderNumber",
                "customerId",
                "shippingName",
                "shippingPhone",
                "shippingEmail",
                "shippingCity",
                "shippingState",
                "subtotal",
                "discount",
                "shippingCharge",
                "grandTotal",
                "paymentMethod",
                "paymentStatus",
                "status",
                "createdAt",
                [
                    fn("COUNT", col("items.id")),
                    "totalItems",
                ],
            ],
            include: [
                {
                    model: OrderItem,
                    as: "items",
                    attributes: [],
                    required: false,
                },
                {
                    model: Customer,
                    as: "customer",
                    attributes: [
                        "id",
                        "name",
                        "phone",
                        "email",
                    ],
                },
            ],
            group: ["Order.id"],
            order: [["createdAt", sort]],
            limit,
            offset,
            subQuery: false,
        });

        return res.status(200).json({
            success: true,
            totalOrders: Array.isArray(count) ? count.length : count,
            currentPage: page,
            totalPages: Math.ceil(
                (Array.isArray(count) ? count.length : count) / limit
            ),
            data: rows,
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch orders.",
        });
    }
}

// ✅ NEW: Get orders for a specific user
async function GetUserOrders(req, res) {
    try {
        const { userId } = req.params;
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        const paymentStatus = req.query.paymentStatus || "";
        const status = req.query.status || "";
        const sort = req.query.sort === "ASC" ? "ASC" : "DESC";

        // Build where clause
        const where = {
            userId: parseInt(userId),
        };

        if (status) {
            where.status = status;
        }

        if (paymentStatus) {
            where.paymentStatus = paymentStatus;
        }

        const { count, rows } = await Order.findAndCountAll({
            where,
            include: [
                {
                    model: OrderItem,
                    as: "items",
                    include: [
                        {
                            model: Product,
                            as: "product",
                            attributes: ["id", "name", "collection"],
                        },
                    ],
                },
                {
                    model: User,
                    as: "user",
                    attributes: ["id", "name", "email"],
                },
                {
                    model: Customer,
                    as: "customer",
                },
            ],
            order: [["createdAt", sort]],
            limit,
            offset,
            distinct: true,
        });

        if (rows.length === 0) {
            return res.status(200).json({
                success: true,
                message: "No orders found for this user",
                userId: parseInt(userId),
                orders: [],
                currentPage: page,
                totalPages: 0,
                total: 0,
            });
        }

        return res.status(200).json({
            success: true,
            userId: parseInt(userId),
            orders: rows,
            currentPage: page,
            totalPages: Math.ceil(count / limit),
            total: count,
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch user orders.",
            error: error.message,
        });
    }
}

// ✅ NEW: Get single order details with items
async function GetOrderById(req, res) {
    try {
        const { orderId } = req.params;

        const order = await Order.findByPk(orderId, {
            include: [
                {
                    model: OrderItem,
                    as: "items",
                    include: [
                        {
                            model: Product,
                            as: "product",
                            attributes: ["id", "name", "collection", "price", "offerPrice"],
                        },
                    ],
                },
                {
                    model: User,
                    as: "user",
                    attributes: ["id", "name", "email", "phoneNo"],
                },
                {
                    model: Customer,
                    as: "customer",
                },
            ],
        });

        if (!order) {
            return res.status(404).json({
                success: false,
                message: "Order not found.",
            });
        }

        return res.status(200).json({
            success: true,
            data: order,
        });

    } catch (error) {
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch order details.",
            error: error.message,
        });
    }
}

async function CreateOrder(req, res) {
    const transaction = await sequelize.transaction();

    try {
        const {
            userId,
            shippingName,
            shippingPhone,
            shippingEmail,
            shippingAddress,
            shippingCity,
            shippingState,
            shippingPincode,

            notes,
            items,
        } = req.body;

        const customer = await Customer.findOne({
            where: {
                // id: customerId,
                userId,
            },
            transaction,
        });

        if (!customer) {
            await transaction.rollback();

            return res.status(404).json({
                success: false,
                message: "Customer not found.",
            });
        }

        if (
            !shippingName ||
            !shippingPhone ||
            !shippingAddress
        ) {
            await transaction.rollback();

            return res.status(400).json({
                success: false,
                message: "Customer details are required.",
            });
        }

        if (!Array.isArray(items) || items.length === 0) {
            await transaction.rollback();
            return res.status(400).json({
                success: false,
                message: "Order must contain at least one product.",
            });
        }


        if (!customer) {
            await transaction.rollback();

            return res.status(404).json({
                success: false,
                message: "Customer not found.",
            });
        }

        // Order number: timestamp + short random suffix to avoid collisions
        const orderNumber = `ORD${Date.now()}${Math.floor(Math.random() * 900 + 100)}`;

        let subtotal = 0;
        const orderItems = [];

        for (const item of items) {
            const quantity = Number(item.quantity);

            if (!item.productId) {
                await transaction.rollback();
                return res.status(400).json({
                    success: false,
                    message: "Each item must include a productId.",
                });
            }

            if (!Number.isInteger(quantity) || quantity <= 0) {
                await transaction.rollback();
                return res.status(400).json({
                    success: false,
                    message: `Invalid quantity for product ${item.productId}.`,
                });
            }

            const product = await Product.findByPk(item.productId, {
                include: [
                    {
                        model: ProductAttribute,
                        as: "attributes",
                    },
                ],
                transaction,
            });

            if (!product) {
                await transaction.rollback();
                return res.status(404).json({
                    success: false,
                    message: `Product ${item.productId} not found.`,
                });
            }

            const variants = product.attributes || [];
            let selectedAttribute = null;

            if (item.attributeId) {
                selectedAttribute = variants.find(
                    (attr) => String(attr.id) === String(item.attributeId)
                );

                if (!selectedAttribute) {
                    await transaction.rollback();
                    return res.status(400).json({
                        success: false,
                        message: `Selected variant not found for product ${item.productId}.`,
                    });
                }
            } else if (variants.length === 1) {
                selectedAttribute = variants[0];
            } else if (variants.length > 1) {
                await transaction.rollback();
                return res.status(400).json({
                    success: false,
                    message: `attributeId is required for product ${item.productId} (multiple variants available).`,
                });
            }

            if (selectedAttribute.quantity < quantity) {
                await transaction.rollback();

                return res.status(400).json({
                    success: false,
                    message: `${product.name} has only ${selectedAttribute.quantity} item(s) left in stock.`,
                });
            }

            const price =
                Number(product.offerPrice) > 0
                    ? Number(product.offerPrice)
                    : Number(product.price);

            const lineTotal = price * quantity;

            subtotal += lineTotal;

            await selectedAttribute.update(
                {
                    quantity: selectedAttribute.quantity - quantity,
                },
                { transaction }
            );

            orderItems.push({
                productId: product.id,
                attributeId: selectedAttribute.id,
                productName: product.name,
                collection: product.collection,
                sku: selectedAttribute?.sku || null,
                image_url: selectedAttribute?.image_url || null,
                color: selectedAttribute?.color || null,
                size: selectedAttribute?.size || null,
                fabric: selectedAttribute?.fabric || null,
                quantity,
                price,
                discount: product.discount || 0,
                subtotal: lineTotal,
            });
        }

        const order = await Order.create(
            {
                userId,
                customerId: customer.id,

                orderNumber,

                shippingName,
                shippingPhone,
                shippingEmail,
                shippingAddress,
                shippingCity,
                shippingState,
                shippingPincode,

                notes,

                subtotal,
                discount: 0,
                shippingCharge: 0,
                grandTotal: subtotal,
            },
            { transaction }
        );

        for (const item of orderItems) {
            await OrderItem.create(
                {
                    orderId: order.id,
                    ...item,
                },
                { transaction }
            );
        }

        await transaction.commit();

        const createdOrder = await Order.findByPk(order.id, {
            include: [
                {
                    model: Customer,
                    as: "customer",
                },
                {
                    model: OrderItem,
                    as: "items",
                },
                {
                    model: User,
                    as: "user",
                    attributes: ["id", "name", "email"],
                },
            ],
        });

        return res.status(201).json({
            success: true,
            message: "Order created successfully.",
            data: createdOrder,
        });
    } catch (error) {
        await transaction.rollback();

        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Failed to create order.",
            error: error.message,
        });
    }
}

async function UpdateOrderStatus(req, res) {
    const transaction = await sequelize.transaction();

    try {
        const { id } = req.params;
        const { status, paymentStatus, paymentMethod } = req.body;

        const validOrderStatus = [
            "Pending",
            "Confirmed",
            "Packed",
            "Shipped",
            "Delivered",
            "Cancelled",
            "Returned",
        ];

        const validPaymentStatus = [
            "Pending",
            "Paid",
            "Failed",
            "Refunded",
        ];

        const validPaymentMethod = [
            "WhatsApp",
            "COD",
            "Online"
        ];

        const order = await Order.findByPk(id, {
            transaction,
            include: [
                {
                    model: OrderItem,
                    as: "items",
                    include: [
                        {
                            model: Product,
                            as: "product",
                            attributes: ["id", "name"],
                        },
                    ],
                },
                {
                    model: User,
                    as: "user",
                    attributes: ["id", "name", "email"],
                },
            ],
        });

        if (!order) {
            await transaction.rollback();

            return res.status(404).json({
                success: false,
                message: "Order not found.",
            });
        }

        const updateData = {};

        if (status) {
            if (!validOrderStatus.includes(status)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid order status.",
                });
            }
            updateData.status = status;
        }

        if (paymentStatus) {
            if (!validPaymentStatus.includes(paymentStatus)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid payment status.",
                });
            }
            updateData.paymentStatus = paymentStatus;
        }

        if (paymentMethod) {
            if (!validPaymentMethod.includes(paymentMethod)) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid payment method.",
                });
            }
            updateData.paymentMethod = paymentMethod;
        }

        const oldStatus = order.status;

        await order.update(updateData, { transaction });

        const shouldRestock =
            updateData.status &&
            ["Cancelled", "Returned"].includes(updateData.status) &&
            !["Cancelled", "Returned"].includes(oldStatus);

        if (shouldRestock) {
            for (const item of order.items) {

                const attribute = await ProductAttribute.findByPk(
                    item.attributeId,
                    { transaction }
                );

                if (!attribute) continue;

                await attribute.update(
                    {
                        quantity:
                            Number(attribute.quantity) +
                            Number(item.quantity),
                    },
                    { transaction }
                );
            }
        }

        await transaction.commit();
        // Send email only if order status changes
        if (
            updateData.status &&
            oldStatus !== updateData.status &&
            order.user?.email
        ) {
            await sendOrderStatusEmail(
                order,
                order.user.email,
                order.user.name
            );
        }

        return res.status(200).json({
            success: true,
            message: "Order updated successfully.",
            data: {
                id: order.id,
                orderNumber: order.orderNumber,
                status: order.status,
                paymentStatus: order.paymentStatus,
                paymentMethod: order.paymentMethod,
                emailSent:
                    updateData.status && order.user?.email ? true : false,
            },
        });
    } catch (error) {
        await transaction.rollback();
        console.error(error);

        return res.status(500).json({
            success: false,
            message: "Failed to update order.",
            error: error.message,
        });
    }
}

module.exports = {
    CreateOrder,
    GetOrders,
    GetUserOrders,
    GetOrderById,
    UpdateOrderStatus,
};
